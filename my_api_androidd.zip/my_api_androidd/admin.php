{
  "users": {
    "user_id_1": {
      "name": "User One",
      "role": 0
    },
    "user_id_2": {
      "name": "Admin User",
      "role": 1
    }
  },
  "uploads": {
    ...
  }
}
