<?php
define('SERVER', 'localhost');
define('UID', 'root');
define('PASSWORD', '');
define('DB_NAME', 'user_data');
?>;

