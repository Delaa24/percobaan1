<?php
// Konfigurasi database
$servername = "localhost";
$username = "root"; 
$password = ""; 
$dbname = "my_api_android";

// Buat koneksi ke database
$conn = new mysqli($servername, $username, $password, $dbname);

// Periksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil dan sanitasi input
    $phoneNumber = $conn->real_escape_string($_POST['phoneNumber']);
    $jenisAjuan = $conn->real_escape_string($_POST['jenisAjuan']);
    $tipeAjuan = $conn->real_escape_string($_POST['tipeAjuan']);

    // Debugging: Output data yang diterima
    echo "Received phoneNumber: " . $phoneNumber . "<br>";
    echo "Received jenisAjuan: " . $jenisAjuan . "<br>";
    echo "Received tipeAjuan: " . $tipeAjuan . "<br>";

    if (isset($_FILES['file']) && $_FILES['file']['error'] == 0) {
        $fileName = basename($_FILES['file']['name']);
        $fileSize = $_FILES['file']['size'];
        $fileTmpName = $_FILES['file']['tmp_name'];
        $fileType = $_FILES['file']['type'];

        // Tentukan direktori unggah
        $uploadDir = 'uploads/';
        $uploadFile = $uploadDir . $fileName;

        // Periksa apakah direktori unggah ada, jika tidak, buat direktori tersebut
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        if (move_uploaded_file($fileTmpName, $uploadFile)) {
            // Gunakan prepared statement untuk mencegah SQL injection
            $stmt = $conn->prepare("INSERT INTO jarkom (phone_number, jenis_ajuan, tipe_ajuan, file_name, file_size, file_type, file_path) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("sssisss", $phoneNumber, $jenisAjuan, $tipeAjuan, $fileName, $fileSize, $fileType, $uploadFile);

            if ($stmt->execute()) {
                echo "File berhasil diunggah dan disimpan di database.";
            } else {
                echo "Error: " . $stmt->error;
            }

            // Tutup statement
            $stmt->close();
        } else {
            echo "Terjadi kesalahan saat mengunggah file.";
        }
    } else {
        echo "Silakan pilih file terlebih dahulu.";
    }
} else {
    echo "Invalid request method.";
}

// Tutup koneksi
$conn->close();
?>
